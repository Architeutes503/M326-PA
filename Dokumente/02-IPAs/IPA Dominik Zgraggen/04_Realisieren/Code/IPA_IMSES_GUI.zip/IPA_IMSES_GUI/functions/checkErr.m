function checkErr(ErrState, handles, hwaitbar)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   (C) Copyright by Siemens Schweiz AG, Building Technologies Group,
%       HVAC Products, 2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Project                     : IMSES
%   Target Hardware             : PC 
%   Target Operating System     : WinXP / Win7 Console
%   Language/Compiler           : Matlab 2010 and higher 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Workfile                    : checkErr.m
%   Author                      : Dominik Zgraggen
%   Version                     : v1.0
%   Date                        : 10-April-2015
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Matlab Informations
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description:
%   checkErr evaluate the State of the Simulation process, if there is
%   an Error, it aborts the Simulation and gives a Message to GUI.
%   This function gets called by TSNet_Test.m after every Step
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function/Interface:
%%  - ErrState  is the Value of the Simulation Error handling (see also 
%     GuiConstants)
%  - handles  structure with handles and user data (see GUIDATA)
%  - hwaitbar  Object to show the Simulation process to the User 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Revision History 
% 	(Put meaningful comments in SourceSafe for log below!)
% 	(Please remove blank lines and very old comments!)
%
%   Document Creation (For IPA)
%   2015-04-10  Dominik Zgraggen, 5559
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    switch ErrState       
        case {GuiConstants.NoError}
            set(handles.txt_State, 'String', GuiConstants.ErrOK);  
            
        case {GuiConstants.TsNet_ReadErr} % in TSNet_Import() -> xlsread
            closeSim(handles, hwaitbar, GuiConstants.ErrRead);
            
        case {GuiConstants.TsNet_Keywords} % in TSNet_Import() -> getInd
            closeSim(handles, hwaitbar, GuiConstants.ErrKeyW);
            
        case {GuiConstants.CtrMdl_LoadErr} % TSNet_Sim() -> load_system
            closeSim(handles, hwaitbar, GuiConstants.ErrLoadCtrMdl);
            
        case  {GuiConstants.SimRunErr}  % in TSNet_Sim() -> sim
            closeSim(handles, hwaitbar, GuiConstants.ErrSim);
            
        case {GuiConstants.Report_WriteErr} % in TSNet_Report() -> xlswrite
            closeSim(handles, hwaitbar, GuiConstants.ErrRep);    
            
        otherwise
            closeSim(handles, hwaitbar, GuiConstants.ErrUnkown)
    end
end

% closeSim gets called if simulation is going to be aborted
% these things should be done, before returning to GUI
function closeSim(handles, hwaitbar, State)
        set(handles.box_Sim, 'BackgroundColor', 'red');
        set(handles.box_Sim, 'String', '');
        set(handles.txt_State, 'String', State);
        delete(hwaitbar)
        error(State);
end





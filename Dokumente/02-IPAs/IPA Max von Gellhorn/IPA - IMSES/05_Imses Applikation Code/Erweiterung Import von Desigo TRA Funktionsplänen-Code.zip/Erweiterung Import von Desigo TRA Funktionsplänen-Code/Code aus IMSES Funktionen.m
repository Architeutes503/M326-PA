%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Code aus der IMES.m Datei
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Akctivate Dissolve algebraic Loop                
h.cheackbox_1_1 = uicontrol('Parent',h.panel_1_1, ...
                        'Style','checkbox',...
                        'String', 'Dissolve algebraic Loop',...
                        'Value', 1, 'Position',[480 20 140 20]);
                    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%                    


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%Code aus der ImportXML.m Datei
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if get(h.cheackbox_1_1,'Value')==1 
    xml = dissolvealgebraicLoop(xml ,h , XMLFileName);
end %if


%%%%%%%%%%%%%%%%%
% Insert Memory Module to dissolve algebraic Loop
      if isfield(lnk, 'MemoryModule') &&   strcmp(lnk.MemoryModule,'true')
         indPort = str2double(get_param([system '/' lnk.FromFBName '/' lnk.FromPin],'Port'));
         %
         blkPos = get_param([system '/' lnk.FromFBName],'Position');
        % UDpos  = [blkPos(1)+round((blkPos(3)-blkPos(1)-25)/2) blkPos(4)+50 ...
        %          blkPos(1)+round((blkPos(3)-blkPos(1)-25)/2)+25 blkPos(4)+50+15];
        UDpos  = [blkPos(3)+10 blkPos(4)+round((blkPos(4)-blkPos(2)-25)/2) ...
                 blkPos(3)+20  blkPos(3)+round((blkPos(4)-blkPos(2))/2)];
         unitDelay = add_block(...
            'built-in/Unit Delay', ...
            [system '/Unit Delay'], ...
            'MakeNameUnique','on', ...
            'Orientation','left', ...
            'Position',[blkPos(3)+40 ...
                        blkPos(2)+20 ...
                        blkPos(3)+55 ...
                        blkPos(2)+35], ...
            'ShowName','off', ...
            'SampleTime', '-1');         
         add_line(system,[lnk.FromFBName '/' sprintf('%d',indPort)],[get_param(unitDelay,'Name') '/1'],'autorouting','on');
         %add_line(system,[get_param(unitDelay,'Name') '/1'],[lnk.ToFBName '/' to],'autorouting','on');
         lnk.FromFBName = [get_param(unitDelay,'Name')];
         fr = '1';
         Send2GUI([' Memory module is inserted after  (' lnk.FromFBName  '/'  lnk.FromPin  ' )'],h.status)
      end% if
      
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
function [ xmllink ] = deleteUnrelatedLinks( xmllink )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   (C) Copyright by Siemens Schweiz AG, Building Technologies Group,
%       HVAC Products, 2013
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Project                     : IMSES
%   Target Hardware             : PC 
%   Target Operating System     : WinXP / Win7 Console
%   Language/Compiler           : Matlab 2010 and higher 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%   Workfile                    : dissolveAlgebraricLoob.m
%   Author                      : Maximilian von Gellhorn
%   Version                     : v0.1
%   Date (yyyy-mm-dd)           : 2013-04-09
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Matlab Informations
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Description:
%   This function deletes from a XML Chart struct every link with has not
%   a connection line to the "InPin" or to the "OutPin". If after this
%   functions, there are links in the struct, there is a algebric loop.
%   If there aren't any links left, there is no algebric loop in 
%   this xml Chart file.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Function/Interface:
%
% Declaration:
%   
%
% Inputs:
%   xmllink           - xmllink Structure of the Links from the Chart file
%   
% Outputs:
%   xmllink           - xmllink Structure 
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%  Revision History 
% 	(Put meaningful comments in SourceSafe for log below!)
% 	(Please remove blank lines and very old comments!)
% 	
%   2013-04-09 09:45
%   Document Created
% 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
bolExitLoop = false;% boolaen for exit the main Loop, wenn all the 
                    % remaining links have a InPut Connoction.
                    
AnzahlElemente = length(xmllink); % Number of Elements in the Array Struct

%loop for deleteing the Links that has no InPut Connections 
while (bolExitLoop ~= true)
    idx = 1;
    bolExitLoop = true;
    
    while idx <= AnzahlElemente % loop through all Elements.
        link2Compare = xmllink{idx}.Attributes.FromFBName;        
        bolDeleted = true;
        for idx2=1 : length(xmllink);% Loop for compare each FromFBName
            % element with all ToFBName elements            % 
            if strcmp(xmllink{idx2}.Attributes.ToFBName,link2Compare);
                %loop through all ToFBName Elements
                bolDeleted = false;
                break 
            end%if    
        end%for
        if bolDeleted % IF the Element has no InPut Connection -> Delete it
            xmllink(:,idx) = [];
            bolExitLoop = false;
            bolDeleted = true;
            AnzahlElemente = AnzahlElemente-1;%Decrease amount of Elements
            %*prevents overflow  of the loop
        else
            idx = idx + 1;
        end%if
    end%while2    
end%while2

bolExitLoop=false;
%loop for deleteing the Links that has no OutPut Connections 
while (bolExitLoop ~= true)
    idx = 1;
    bolExitLoop = true;
    
    while idx <= AnzahlElemente % loop through all Elements.
        link2Compare = xmllink{idx}.Attributes.ToFBName;        
        bolDeleted = true;
        for idx2=1 : length(xmllink);% Loop for compare each FromFBName
            % element with all ToFBName elements            % 
            if strcmp(xmllink{idx2}.Attributes.FromFBName,link2Compare);
                %loop through all ToFBName Elements
                bolDeleted = false;
                break 
            end%if    
        end%for
        if bolDeleted % IF the Element has no InPut Connection -> Delete it
            xmllink(:,idx) = [];
            bolExitLoop = false;
            bolDeleted = true;
            AnzahlElemente = AnzahlElemente-1;%Decrease amount of Elements
            %*prevents overflow  of the loop
        else
            idx = idx + 1;
        end%if
    end%while2    
end%while2


end


















